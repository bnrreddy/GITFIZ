package com.cognizant.genc.cohort57.pod3;



/**
 * Unit test for Grizfit-GymManagementSystemApi.
 */
public class AppTest 
{
   
}
