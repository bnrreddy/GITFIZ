package com.cognizant.genc.cohort57.pod3.serviceimpl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.genc.cohort57.pod3.entity.GymMembershipDetails;
import com.cognizant.genc.cohort57.pod3.entity.GymMembershipInfoSP;
import com.cognizant.genc.cohort57.pod3.entity.GymMembershipPlanInfoSP;
import com.cognizant.genc.cohort57.pod3.entity.LkpCity;
import com.cognizant.genc.cohort57.pod3.entity.LkpState;
import com.cognizant.genc.cohort57.pod3.model.City;
import com.cognizant.genc.cohort57.pod3.model.GymMembershipDetailsModel;
import com.cognizant.genc.cohort57.pod3.model.GymMembershipInfoModel;
import com.cognizant.genc.cohort57.pod3.model.PlanInfo;
import com.cognizant.genc.cohort57.pod3.model.State;
import com.cognizant.genc.cohort57.pod3.repository.CityLookupRepository;
import com.cognizant.genc.cohort57.pod3.repository.GymMembershipDetailsRepository;
import com.cognizant.genc.cohort57.pod3.repository.GymMembershipInfoSPRepository;
import com.cognizant.genc.cohort57.pod3.repository.GymMembershipPlanInfoSPRepository;
import com.cognizant.genc.cohort57.pod3.repository.SateLookupRepository;
import com.cognizant.genc.cohort57.pod3.service.IGymMembershipService;

@Service
public class GymMembershipService implements IGymMembershipService {

	@Autowired
	private GymMembershipDetailsRepository _gymMembershipDetailsRepository;
	@Autowired
	private SateLookupRepository _stateLookupRepository;
	@Autowired
	private CityLookupRepository _cityLookupRepository;
	@Autowired
	private GymMembershipInfoSPRepository _gymMembershipInfoSPRepository;
	@Autowired
	private GymMembershipPlanInfoSPRepository _gymMembershipPlanInfoSPRepository;

	@Override
	public GymMembershipDetailsModel getGymMembershipDetails(int memberId) {

		GymMembershipDetailsModel gymMembershipDetailsModelObj = new GymMembershipDetailsModel();
		GymMembershipDetails gymMembershipDetails = _gymMembershipDetailsRepository.getGymMembershipDetails(memberId);
		if (gymMembershipDetails == null)
			return null;
		gymMembershipDetailsModelObj.setId(gymMembershipDetails.getId());
		gymMembershipDetailsModelObj.setName(gymMembershipDetails.getName());
		gymMembershipDetailsModelObj.setEmail(gymMembershipDetails.getEmail());
		gymMembershipDetailsModelObj.setPhone(gymMembershipDetails.getPhone());
		gymMembershipDetailsModelObj.setGender(gymMembershipDetails.getGender());
		gymMembershipDetailsModelObj.setAge(gymMembershipDetails.getAge());
		gymMembershipDetailsModelObj.setAddress(gymMembershipDetails.getAddress());
		gymMembershipDetailsModelObj.setZipCode(gymMembershipDetails.getZipCode());
		gymMembershipDetailsModelObj.setStateId(gymMembershipDetails.getStateId());
		gymMembershipDetailsModelObj.setCityId(gymMembershipDetails.getCityId());
		gymMembershipDetailsModelObj.setStartDate(gymMembershipDetails.getStartDate());
		gymMembershipDetailsModelObj.setPlanId(gymMembershipDetails.getPlanId());
		gymMembershipDetailsModelObj.setAmount(gymMembershipDetails.getAmount());
		gymMembershipDetailsModelObj.setEndDate(gymMembershipDetails.getEndDate());

		return gymMembershipDetailsModelObj;
	}

	@Override
	public int addOrUpdateGymMember(GymMembershipDetailsModel gymMembershipDetailsModel) {

		int id = gymMembershipDetailsModel.getId();
		String name = gymMembershipDetailsModel.getName();
		String email = gymMembershipDetailsModel.getEmail();
		long phone = gymMembershipDetailsModel.getPhone();
		String gender = gymMembershipDetailsModel.getGender();
		int age = gymMembershipDetailsModel.getAge();
		String address = gymMembershipDetailsModel.getAddress();
		int zipCode = gymMembershipDetailsModel.getZipCode();
		int stateId = gymMembershipDetailsModel.getStateId();
		int cityId = gymMembershipDetailsModel.getCityId();
		Date startDate = gymMembershipDetailsModel.getStartDate();
		int planId = gymMembershipDetailsModel.getPlanId();
		double amount = gymMembershipDetailsModel.getAmount();
		Date endDate = gymMembershipDetailsModel.getEndDate();

		if (id == 0) {
			int res = _gymMembershipDetailsRepository.addGymMember(name, email, phone, gender, age, address, zipCode,
					stateId, cityId, startDate, planId, amount, endDate);
			return res;
		} else {
			int res = _gymMembershipDetailsRepository.updateGymMember(id, name, email, phone, gender, age, address,
					zipCode, stateId, cityId, startDate, planId, amount, endDate);
			return res;
		}
	}

	@Override
	public int deleteGymMember(int memberId) {

		int res = _gymMembershipDetailsRepository.deleteGymMember(memberId);
		return res;
	}

	@Override
	public List<State> getStates() {

		List<State> states = new ArrayList<>();
		List<LkpState> lkpStates = _stateLookupRepository.getSates();
		if (lkpStates == null)
			return null;
		for (LkpState lkpState : lkpStates) {
			State state = new State();
			state.setStateId(lkpState.getStateId());
			state.setStateName(lkpState.getStateName());
			states.add(state);
		}
		return states;
	}

	@Override
	public List<City> getCities(int stateId) {

		List<City> cities = new ArrayList<>();
		List<LkpCity> lkpCities = _cityLookupRepository.getCities(stateId);
		if (lkpCities == null)
			return null;
		for (LkpCity lkpCity : lkpCities) {
			City city = new City();
			city.setCityId(lkpCity.getCityId());
			city.setCityName(lkpCity.getCityName());
			cities.add(city);
		}
		return cities;
	}

	@Override
	public List<GymMembershipInfoModel> getGymMembershipInfo() {

		List<GymMembershipInfoModel> gymMembershipInfoModelList = new ArrayList<>();
		List<GymMembershipInfoSP> gymMembershipInfoList = _gymMembershipInfoSPRepository.getGymMembershipInfo();
		if (gymMembershipInfoList == null)
			return null;
		for (GymMembershipInfoSP gymMembership : gymMembershipInfoList) {
			GymMembershipInfoModel gymMembershipInfoModelObj = new GymMembershipInfoModel();
			gymMembershipInfoModelObj.setId(gymMembership.getId());
			gymMembershipInfoModelObj.setName(gymMembership.getName());
			gymMembershipInfoModelObj.setPhone(gymMembership.getPhone());
			gymMembershipInfoModelObj.setStartDate(gymMembership.getStartDate());
			gymMembershipInfoModelObj.setPlan(gymMembership.getPlan());
			gymMembershipInfoModelObj.setEndDate(gymMembership.getEndDate());
			gymMembershipInfoModelList.add(gymMembershipInfoModelObj);
		}
		return gymMembershipInfoModelList;
	}

	@Override
	public List<PlanInfo> getGymMembershipPlanInfo() {

		List<PlanInfo> planInfoList = new ArrayList<>();
		List<GymMembershipPlanInfoSP> gymMembershipPlanInfoSPList = _gymMembershipPlanInfoSPRepository
				.getGymMembershipPlanInfo();
		if (gymMembershipPlanInfoSPList == null)
			return null;
		for (GymMembershipPlanInfoSP gymMembershipPlan : gymMembershipPlanInfoSPList) {
			PlanInfo planInfoObj = new PlanInfo();
			planInfoObj.setPlanId(gymMembershipPlan.getPlanId());
			planInfoObj.setPlanName(gymMembershipPlan.getPlanName());
			planInfoObj.setAmount(gymMembershipPlan.getAmount());
			planInfoObj.setDuration(gymMembershipPlan.getDuration());

			planInfoList.add(planInfoObj);
		}
		return planInfoList;
	}

}
