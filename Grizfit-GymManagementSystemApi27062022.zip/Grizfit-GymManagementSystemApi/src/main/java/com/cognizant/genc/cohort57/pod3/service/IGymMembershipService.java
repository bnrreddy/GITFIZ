package com.cognizant.genc.cohort57.pod3.service;

import java.util.List;

import com.cognizant.genc.cohort57.pod3.model.City;
import com.cognizant.genc.cohort57.pod3.model.GymMembershipDetailsModel;
import com.cognizant.genc.cohort57.pod3.model.GymMembershipInfoModel;
import com.cognizant.genc.cohort57.pod3.model.PlanInfo;
import com.cognizant.genc.cohort57.pod3.model.State;

public interface IGymMembershipService {

	GymMembershipDetailsModel getGymMembershipDetails(int memberId);
	
	int addOrUpdateGymMember(GymMembershipDetailsModel gymMembershipDetailsModel);
	
	int deleteGymMember(int memberId);
	
	List<GymMembershipInfoModel> getGymMembershipInfo();

	List<State> getStates();

	List<City> getCities(int stateId);
	
	List<PlanInfo> getGymMembershipPlanInfo();
}
