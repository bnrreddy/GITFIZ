package com.cognizant.genc.cohort57.pod3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.genc.cohort57.pod3.entity.LkpAppSubscription;

@Repository
public interface AppSubscriptionLookupRepository extends JpaRepository<LkpAppSubscription, Integer> {

	@Query(value = "SELECT * FROM Lkp_AppSubscription WHERE SubscriptionKey  =?1 AND IsActive = 1 ;", nativeQuery = true)
	LkpAppSubscription verifySubscription(String subscriptionKey);
}
