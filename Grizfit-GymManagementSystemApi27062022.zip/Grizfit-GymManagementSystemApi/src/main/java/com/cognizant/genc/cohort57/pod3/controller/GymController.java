package com.cognizant.genc.cohort57.pod3.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.genc.cohort57.pod3.model.City;
import com.cognizant.genc.cohort57.pod3.model.GymMembershipDetailsModel;
import com.cognizant.genc.cohort57.pod3.model.GymMembershipInfoModel;
import com.cognizant.genc.cohort57.pod3.model.PlanInfo;
import com.cognizant.genc.cohort57.pod3.model.State;
import com.cognizant.genc.cohort57.pod3.service.IGymMembershipService;

@RestController
@CrossOrigin(origins="http://localhost:3000")
@RequestMapping("/api/gym")
public class GymController {

	@Autowired
	private IGymMembershipService _gymMembershipService;

	@GetMapping("/getGymMembershipDetails")
	public ResponseEntity<?> getGymMembershipDetails(@RequestParam int memberId) {

		try {
			GymMembershipDetailsModel GymMembershipDetailsRes = _gymMembershipService.getGymMembershipDetails(memberId);
			if (GymMembershipDetailsRes == null)
				throw new Exception("No Data Found");
			return new ResponseEntity<>(GymMembershipDetailsRes, HttpStatus.OK);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}

	@PostMapping("/addOrUpdateGymMember")
	public ResponseEntity<?> addOrUpdateGymMember(@RequestBody GymMembershipDetailsModel gymMembershipDetailsModel) {

		try {
			int res = _gymMembershipService.addOrUpdateGymMember(gymMembershipDetailsModel);
			if (res == 0)
				throw new Exception("Fail to Add Gym Member");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}

	@DeleteMapping("/deleteGymMember")
	public ResponseEntity<?> deleteGymMember(@RequestParam int memberId) {

		try {
			int res = _gymMembershipService.deleteGymMember(memberId);
			if (res == 0)
				throw new Exception("Fail to Delete Gym Member");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}

	@GetMapping("/getGymMembershipInfo")
	public ResponseEntity<?> getGymMembershipInfo() {

		try {
			List<GymMembershipInfoModel> gymMembershipInfo = _gymMembershipService.getGymMembershipInfo();
			if (gymMembershipInfo == null)
				throw new Exception("No Gym Member Found");
			return new ResponseEntity<>(gymMembershipInfo, HttpStatus.OK);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}

	@GetMapping("/getStates")
	public ResponseEntity<?> getStates() {

		try {
			List<State> states = _gymMembershipService.getStates();
			if (states == null)
				throw new Exception("No State Found");
			return new ResponseEntity<>(states, HttpStatus.OK);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}

	@GetMapping("/getCities")
	public ResponseEntity<?> getCities(@RequestParam int stateId) {

		try {
			List<City> cities = _gymMembershipService.getCities(stateId);
			if (cities == null)
				throw new Exception("No City Found");
			return new ResponseEntity<>(cities, HttpStatus.OK);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}
	
	@GetMapping("/getGymMembershipPlanInfo")
	public ResponseEntity<?> getGymMembershipPlanInfo() {

		try {
			List<PlanInfo> gymMembershipPlanInfo = _gymMembershipService.getGymMembershipPlanInfo();
			if (gymMembershipPlanInfo == null)
				throw new Exception("No Plan Found");
			return new ResponseEntity<>(gymMembershipPlanInfo, HttpStatus.OK);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}
}
