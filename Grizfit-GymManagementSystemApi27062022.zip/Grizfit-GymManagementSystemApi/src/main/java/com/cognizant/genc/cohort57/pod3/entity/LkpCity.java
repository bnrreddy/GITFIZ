package com.cognizant.genc.cohort57.pod3.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Lkp_City")
public class LkpCity {

	@Id
	@GeneratedValue
	@Column(name = "CityId")
	private int cityId;

	@Column(name = "CityName")
	private String cityName;

	@Column(name = "StateId")
	private int stateId;

	public LkpCity() {
	}

	public int getCityId() {
		return cityId;
	}

	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public int getStateId() {
		return stateId;
	}

	public void setStateId(int stateId) {
		this.stateId = stateId;
	}

}
