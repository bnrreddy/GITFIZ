package com.cognizant.genc.cohort57.pod3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.genc.cohort57.pod3.entity.GymMembershipPlanInfoSP;

@Repository
public interface GymMembershipPlanInfoSPRepository extends JpaRepository<GymMembershipPlanInfoSP, Integer> {

	@Query(value = "CALL sp_GetGymMembershipPlanInfo();", nativeQuery = true)
	List<GymMembershipPlanInfoSP> getGymMembershipPlanInfo();
}
