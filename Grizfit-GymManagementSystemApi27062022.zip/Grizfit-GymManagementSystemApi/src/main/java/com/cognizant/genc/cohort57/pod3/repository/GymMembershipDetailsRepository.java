package com.cognizant.genc.cohort57.pod3.repository;

import java.sql.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.genc.cohort57.pod3.entity.GymMembershipDetails;

@Repository
public interface GymMembershipDetailsRepository extends JpaRepository<GymMembershipDetails, Integer> {

	@Query(value = "SELECT * FROM GymMembershipDetails WHERE GMD_Id = ?1 AND GMD_IsActive = 1;", nativeQuery = true)
	GymMembershipDetails getGymMembershipDetails(int memberId);
	
	@Modifying
	@Transactional
	@Query(value = "INSERT INTO GymMembershipDetails(GMD_Name, GMD_Email, GMD_Phone, GMD_Gender, GMD_Age, GMD_Address,"
			+ "GMD_ZipCode, GMD_StateId, GMD_CityId, GMD_StartDate, GMD_PlanId, GMD_Amount, GMD_EndDate) "
			+ "VALUES(:name, :email, :phone, :gender, :age, :address, :zipCode, :stateId, :cityId, :startDate, :planId, "
			+ ":amount, :endDate);", nativeQuery = true)
	int addGymMember(
			@Param("name") String name, 
			@Param("email") String email, 
			@Param("phone") long phone,
			@Param("gender") String gender,
			@Param("age") int age,
			@Param("address") String address,
			@Param("zipCode") int zipCode,
			@Param("stateId") int stateId,
			@Param("cityId") int cityId,
			@Param("startDate") Date startDate,
			@Param("planId") int planId,
			@Param("amount") double amount,
			@Param("endDate") Date endDate
			);
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE GymMembershipDetails SET GMD_Name = :name, GMD_Email = :email, GMD_Phone = :phone, "
			+ "GMD_Gender = :gender, GMD_Age = :age, GMD_Address = :address, GMD_ZipCode = :zipCode, GMD_StateId = :stateId, "
			+ "GMD_CityId = :cityId, GMD_StartDate = :startDate, GMD_PlanId = :planId, GMD_Amount = :amount, "
			+ "GMD_EndDate = :endDate WHERE GMD_Id = :id ;", nativeQuery = true)
	int updateGymMember(
			@Param("id") int id,
			@Param("name") String name, 
			@Param("email") String email, 
			@Param("phone") long phone,
			@Param("gender") String gender,
			@Param("age") int age,
			@Param("address") String address,
			@Param("zipCode") int zipCode,
			@Param("stateId") int stateId,
			@Param("cityId") int cityId,
			@Param("startDate") Date startDate,
			@Param("planId") int planId,
			@Param("amount") double amount,
			@Param("endDate") Date endDate
			);
	
	@Modifying
	@Transactional
	@Query(value = "UPDATE GymMembershipDetails SET GMD_IsActive = 0 WHERE GMD_Id = :memberId ;", nativeQuery = true)
	int deleteGymMember(@Param("memberId") int memberId);
}
