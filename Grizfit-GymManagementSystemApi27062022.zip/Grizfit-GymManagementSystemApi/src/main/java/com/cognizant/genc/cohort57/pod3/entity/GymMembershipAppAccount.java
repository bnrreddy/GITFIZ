package com.cognizant.genc.cohort57.pod3.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "GymMembershipAppAccount")
public class GymMembershipAppAccount {

	@Id
	@GeneratedValue
	@Column(name = "AccountId")
	private int accountId;

	@Column(name = "SubscriptionId")
	private int subscriptionId;

	@Column(name = "AccountName")
	private String accountName;

	@Column(name = "AccountEmail")
	private String accountEmail;

	@Column(name = "AccountPassword")
	private String accountPassword;

	public GymMembershipAppAccount() {
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public int getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(int subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountEmail() {
		return accountEmail;
	}

	public void setAccountEmail(String accountEmail) {
		this.accountEmail = accountEmail;
	}

	public String getAccountPassword() {
		return accountPassword;
	}

	public void setAccountPassword(String accountPassword) {
		this.accountPassword = accountPassword;
	}

}
