package com.cognizant.genc.cohort57.pod3.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Lkp_AppSubscription")
public class LkpAppSubscription {

	@Id
	@GeneratedValue
	@Column(name = "SubscriptionId")
	private int subscriptionId;

	@Column(name = "SubscriptionKey")
	private String subscriptionKey;

	public LkpAppSubscription() {

	}

	public int getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(int subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public String getSubscriptionKey() {
		return subscriptionKey;
	}

	public void setSubscriptionKey(String subscriptionKey) {
		this.subscriptionKey = subscriptionKey;
	}

}
