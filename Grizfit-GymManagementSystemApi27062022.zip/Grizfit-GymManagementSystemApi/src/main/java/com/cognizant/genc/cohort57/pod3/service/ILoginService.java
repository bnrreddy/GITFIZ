package com.cognizant.genc.cohort57.pod3.service;

import com.cognizant.genc.cohort57.pod3.model.Account;
import com.cognizant.genc.cohort57.pod3.model.LoginModel;

public interface ILoginService {

	LoginModel validateGymOwner(String emailId, String password);
	
	int createGymAccount(Account account);
}
